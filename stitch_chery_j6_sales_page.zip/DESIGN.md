---
name: Voltage Rugged
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c8c6c5'
  primary: '#c8c6c5'
  on-primary: '#313030'
  primary-container: '#1a1a1a'
  on-primary-container: '#848282'
  inverse-primary: '#5f5e5e'
  secondary: '#ffffff'
  on-secondary: '#263500'
  secondary-container: '#b9f600'
  on-secondary-container: '#516e00'
  tertiary: '#ffb693'
  on-tertiary: '#561f00'
  tertiary-container: '#320f00'
  on-tertiary-container: '#db5b00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#b9f600'
  secondary-fixed-dim: '#a2d800'
  on-secondary-fixed: '#141f00'
  on-secondary-fixed-variant: '#384e00'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb693'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7a3000'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  h1:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
  stats:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: -0.02em
spacing:
  unit: 4px
  gutter: 24px
  margin: 64px
  section-gap: 128px
  max-width: 1440px
---

## Brand & Style
The design system embodies the intersection of off-road capability and futuristic electrification. It is engineered to evoke a sense of precision, power, and adventurous spirit. The brand personality is unapologetic, industrial, and high-performance.

The design style is a hybrid of **High-Contrast Bold** and **Modern Industrial**. It utilizes sharp edges and a structural layout to mimic the rugged frame of the Chery J6, while high-contrast color pairings and subtle tech-gradients suggest advanced EV technology. The UI should feel like a premium digital cockpit: functional, data-driven, and physically robust.

## Colors
The palette is dominated by **Deep Charcoal (#1A1A1A)** to establish a premium, "stealth" foundation. **Electric Lime (#C0FF00)** serves as the primary action color, representing high-voltage energy and modern tech. **Safety Orange (#FF6B00)** is used sparingly for utility accents, rugged callouts, or performance highlights.

Backgrounds alternate between the Deep Charcoal for immersive sections and a **Clean Light Gray (#F5F5F5)** for data-heavy specs or pricing sections to ensure maximum readability and a high-end editorial feel. Gradients should be subtle, moving from charcoal to a slightly lighter slate to provide depth without sacrificing the "flat" industrial aesthetic.

## Typography
The typography strategy prioritizes a technical, geometric aesthetic. **Space Grotesk** is used for all headlines and labels to provide a futuristic, industrial edge. For body copy, **Inter** provides a highly legible, neutral balance to the aggressive display type. 

Large-scale "stats" styling is specifically defined for performance metrics (0-100 km/h, Range, Horsepower), emphasizing the vehicle's technical superiority. Use uppercase transformations for labels and subheaders to reinforce the rugged, utilitarian nature of the design system.

## Layout & Spacing
This design system utilizes a **Fixed Grid** model. The layout is structured on a 12-column grid with a maximum container width of 1440px. Gutters are kept tight (24px) to maintain a dense, engineered feel.

Generous vertical "section-gaps" (128px) allow high-contrast imagery to breathe, creating a premium editorial rhythm. Content should often be offset or asymmetrical to mimic movement and terrain, while still adhering to the underlying 12-column rigidity.

## Elevation & Depth
Depth is achieved through **Tonal Layering** and **High-Contrast Outlines** rather than traditional shadows. Surfaces are stacked using varying shades of charcoal (e.g., #1A1A1A on #242424).

When an element requires focus, a 1px solid border in Electric Lime or a semi-transparent white is used. Background blurs (Glassmorphism) are reserved strictly for the navigation bar and floating technical overlays to maintain a "heads-up display" (HUD) feel without softening the overall rugged aesthetic.

## Shapes
The shape language is defined by **Sharp Edges (0px)**. This reinforces the rugged, armor-like qualities of the J6. Any departure from 0px should be intentional and limited to circular iconography or internal components like toggle tracks. Container edges, buttons, and input fields must remain perfectly square to project strength and structural integrity.

## Components
- **Buttons:** Rectangular with 0px radius. Primary buttons use a solid Electric Lime fill with black text. Secondary buttons use a 2px "ghost" border with Lime or White text.
- **Input Fields:** Dark charcoal background with a subtle 1px bottom-border. On focus, the border transitions to a full 1px Electric Lime frame.
- **Cards:** No shadows. Cards use a slightly lighter charcoal fill than the background and are separated by 1px borders or contrasting background shifts.
- **Chips/Tags:** Small, rectangular labels with uppercase Space Grotesk text. Used for "In Stock" or "New Feature" badges.
- **Performance HUD:** A custom component for the sales page featuring large-scale stats, a progress bar (for battery/range), and technical line-art icons.
- **Image Masks:** Use 45-degree angled "clipped" corners for hero images or feature callouts to enhance the aggressive, military-grade aesthetic.